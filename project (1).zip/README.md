# MicroDetail AI Camera

Native Android camera app (Kotlin, Camera2) for extreme close-up detail photography,
built for the OnePlus 7 Pro. All processing runs on the phone.

## Status
- Phase 0 (this version): build pipeline check. The app lists the cameras the phone exposes.
- Phase 1: camera diagnostics (next)

## Build
GitHub Actions builds the APK automatically. See `.github/workflows/build.yml`.
Local build (needs Android SDK, JDK 17, Gradle 8.9): `gradle assembleDebug`

## Versions
Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Gradle 8.9, JDK 17, compileSdk 34, minSdk 26.

## Signing
`app/debug.keystore` is a fixed test key so new builds can update old installs.
It is for test builds only.
