// Top-level build file. Plugin versions are chosen to work together:
// Android Gradle Plugin 8.5.2 + Kotlin 1.9.24 + Gradle 8.9 + JDK 17.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
