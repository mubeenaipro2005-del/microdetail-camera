plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.microdetail.camera"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.microdetail.camera"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-phase0"
    }

    // A fixed debug key is stored in the project (app/debug.keystore).
    // Without it, every GitHub build gets a different key and Android refuses
    // to update the app over the old one ("App not installed").
    // This key is for test builds only, never for a Play Store release.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
