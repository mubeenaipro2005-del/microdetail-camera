package com.microdetail.camera

import org.junit.Assert.assertEquals
import org.junit.Test

class CameraFormatTest {

    @Test
    fun facingNames_areCorrect() {
        assertEquals("Front", CameraFormat.facingName(0))
        assertEquals("Back", CameraFormat.facingName(1))
        assertEquals("External", CameraFormat.facingName(2))
        assertEquals("Unknown", CameraFormat.facingName(null))
        assertEquals("Unknown", CameraFormat.facingName(99))
    }

    @Test
    fun megapixels_48MpSensor() {
        assertEquals(48.0, CameraFormat.megapixels(8000, 6000), 0.0001)
    }

    @Test
    fun megapixels_12MpSensor() {
        assertEquals(12.2, CameraFormat.megapixels(4032, 3024), 0.0001)
    }
}
