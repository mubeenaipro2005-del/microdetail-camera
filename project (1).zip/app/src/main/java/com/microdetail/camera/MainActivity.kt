package com.microdetail.camera

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

/**
 * Phase 0: a simple screen that proves three things:
 *  1. the app was built by GitHub and installs on the phone,
 *  2. the app can reach the Camera2 system,
 *  3. we can read basic facts about every camera the phone exposes.
 * Reading camera facts needs no camera permission.
 */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val report = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setPadding(40, 100, 40, 60)
            text = buildReport()
            setTextIsSelectable(true)
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#101418"))
            addView(report)
        }
        setContentView(scroll)
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        sb.appendLine("MicroDetail AI Camera")
        sb.appendLine("Version ${BuildConfigInfo.VERSION} - Phase 0 build check")
        sb.appendLine()
        sb.appendLine("Phone: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine()

        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val ids = manager.cameraIdList
            sb.appendLine("Cameras visible to apps: ${ids.size}")
            for (id in ids) {
                val chars = manager.getCameraCharacteristics(id)
                val facing = CameraFormat.facingName(chars.get(CameraCharacteristics.LENS_FACING))
                val size = chars.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
                val mp = if (size != null) {
                    "${CameraFormat.megapixels(size.width, size.height)} MP sensor area"
                } else {
                    "sensor size unknown"
                }
                sb.appendLine("- Camera $id: $facing, $mp")
            }
        } catch (e: Exception) {
            sb.appendLine("Could not read the cameras: ${e.message}")
        }

        sb.appendLine()
        sb.appendLine("If you can read this, Phase 0 worked.")
        sb.appendLine("Please send a screenshot of this screen.")
        return sb.toString()
    }
}

/** Kept separate so the version text lives in one place. */
object BuildConfigInfo {
    const val VERSION = "0.1.0"
}
