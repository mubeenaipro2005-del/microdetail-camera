package com.microdetail.camera

/**
 * Small pure helpers for showing camera facts as plain text.
 * They contain no Android calls, so they can be tested automatically.
 */
object CameraFormat {

    /** Numbers match CameraCharacteristics.LENS_FACING_FRONT/BACK/EXTERNAL. */
    fun facingName(facing: Int?): String = when (facing) {
        0 -> "Front"
        1 -> "Back"
        2 -> "External"
        else -> "Unknown"
    }

    /** Sensor size in megapixels, rounded to one decimal place. */
    fun megapixels(width: Int, height: Int): Double =
        Math.round(width.toLong() * height / 100_000.0) / 10.0
}
